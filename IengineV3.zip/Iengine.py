from colorama import Fore, init
import os
import subprocess
import sys
import glob
import time

def englishtut():
    print(Fore.LIGHTBLUE_EX + "           Welcome to the tutorial")
    time.sleep(1)
    print('- This Program is made for databases (supports .txt, .db, .sql, .csv etc).')
    time.sleep(1)
    print("- It's useful for searching an username of something of your choice in the databases quick and easily.")
    time.sleep(1)
    print("- The speed depends of the size of your folder.")
    time.sleep(1)
    print("- If you read help.txt in the zip folder and if you did the steps, you can run the program by right clicking on the folder and go to 'send to' button then press Iengine.")
    time.sleep(1)
    print("- Fore more informations contact enemy.inf on discord for more helpful informations.")
    time.sleep(1)

def frenchtut():
    print(Fore.LIGHTBLUE_EX + "           Bienvenue au tutoriel")
    time.sleep(1)
    print('- Ce programme est fait pour les bases de données (supporte .txt, .sql, .db, .csv etc).')
    time.sleep(1)
    print("- Il est utile pour rechercher un nom d'utilisateur ou quelque chose dans ton choix dans les bases de données rapidement et facilement.")
    time.sleep(1)
    print("- La vitesse dépend de la taille du fichier")
    time.sleep(1)
    print("- Si vous avez lu le fichier help.txt dans le dossier zip et si vous avez suivi les étapes, vous pouvez exécuter le programme en cliquant avec le bouton droit de la souris sur le dossier et en cliquant sur le bouton 'envoyer vers', puis en appuyant sur Iengine.")
    time.sleep(1)
    print("- Pour plus d'informations, contactez enemy.inf sur discord.")
    time.sleep(1)

def run_searchengine():
    init(autoreset=True)

    def clear():
        os.system("cls")

    def grep_windows(pattern, file_location, filename):
        try:
            full_file_path = os.path.join(file_location, filename)
            result = subprocess.run(['findstr', pattern, full_file_path], capture_output=True, text=True)
            if result.returncode == 0:
                return full_file_path, result.stdout
        except FileNotFoundError:
            return f"{Fore.RED}Error: 'findstr' command not found. Make sure you are running on Windows."

    def maina():
        print(Fore.RED + """
.___           ___________              .__               
|   |          \_   _____/ ____    ____ |__| ____   ____  
|   |  ______   |    __)_ /    \  / ___\|  |/    \_/ __ \ 
|   | /_____/   |        \   |  \/ /_/  >  |   |  \  ___/ 
|___|          /_______  /___|  /\___  /|__|___|  /\___  >
                       \/     \//_____/         \/     \/     V3          - By enemy  """)
        
        if len(sys.argv) == 1:
            print(Fore.GREEN + f"\n[?] File Location: ")
            file_location = input("> ")
        else:
            file_location = sys.argv[1]
        
        while True:
            print(Fore.YELLOW + f"Current directory: {file_location}")
            while True:
                print(Fore.LIGHTYELLOW_EX + '[?] Enter a command (help for commands):')
                cmds = input('> ')
                if cmds == 'help':
                    print('''
****************************************************************
*                            Commands                          *
****************************************************************
*   - run        Runs the program                              *
*   - cls        Clear terminal.                               *
*   - credits    Credits                                       *
*   - tutorial   Tutorial for retarded people                  *
*   - errors     Known error fixes                             *
*   -                                                          *
*   -                                                          *
*   -                                                          *
*   -                                                          *
*   -                                                          *
*   -                                                          *
*   -                                                          *
*   -                                                          *
*   -                                                          *
*   -                                                          *
*   -                                                          *
*   -                                                          *
*                                                              *
****************************************************************''')
                elif cmds == 'cls':
                    os.system('cls')
                elif cmds == 'credits':
                    print("""     CREDITS\n Everything is made by jncl (jncl_ahah discord)\n\nPrevious Usernames : ENEMY, Incognito.mode""")
                elif cmds == 'tutorial':
                    print("""
                            Choose a language for the tutorial:
                            - english
                            - french""")
                    language = input('> ')
                    if language == 'english':
                        englishtut()
                    elif language == 'french':
                        frenchtut()
                    else:
                        print('Please enter a valid language.')
                elif cmds == 'errors':
                    print(Fore.RED + """               KNOWN ERRORS
                                 - Not finding a readable file
                                   - Try lauching the app via 'send to' by rightclicking the file (if you done the help.txt file in the zip folder)
                                 Contact jncl_ahah for more errors then i will update.""")
                elif cmds == 'run':
                    print(Fore.GREEN + "[?] Enter the search pattern:")
                    pattern = input("> ")
                    print(Fore.LIGHTCYAN_EX + "Checking...")
                    
                    txt_files = glob.glob(os.path.join(file_location, "*.txt")) + glob.glob(
                        os.path.join(file_location, "*.sql")) + glob.glob(
                        os.path.join(file_location, "*.csv")) + glob.glob(
                        os.path.join(file_location, "*.db")) + glob.glob(
                        os.path.join(file_location, "*.py"))
                    
                    if not txt_files:
                        print(Fore.RED + "No Readable files found in the specified directory.")
                        time.sleep(1)
                        sys.exit()
                    
                    print(Fore.GREEN + f"Found {len(txt_files)} files.")
                    
                    found_something = False
                    for file in txt_files:
                        results = grep_windows(pattern, file_location, os.path.basename(file))
                        if results:
                            found_something = True
                            file_path, content = results
                            print(Fore.YELLOW + f"{Fore.YELLOW}{file_path}: ")
                            print(content)
                    
                    if not found_something:
                        print(Fore.YELLOW + "No results found.")
                else:
                    print(Fore.RED + "Invalid command.")
    
    maina()

run_searchengine()
os.environ["RUN_SEARCHENGINE"] = 'YES'
